# Third-party notices

REDUX uses the following third-party libraries as Gradle dependencies and does not copy their source into this project:

- **libadb-android** — https://github.com/MuntashirAkon/libadb-android — dual-licensed GPL-3.0-or-later or Apache-2.0; check the dependency's current license files and notices at build/release time.
- **sun-security-android** — https://github.com/MuntashirAkon/sun-security-android — used for Android-compatible X.509 certificate construction; repository license is GPL-2.0 with Classpath exception according to its public page. Check transitive notice obligations before redistribution.
- **Conscrypt** — https://github.com/google/conscrypt — TLS provider. Preserve its Apache 2.0 license and any bundled notices in a redistributed binary.

Reference-only projects (no source copied):

- **AdbShellTool** by Pablo Ajo — MIT — https://github.com/pabloajoinglez/AdbShellTool
- **tananaev/adblib** — https://github.com/tananaev/adblib
- Gorilla Tag community mod/menu projects listed in `docs/RESEARCH.md`.

Before publishing a release, verify all dependency licenses and include the exact notices/licenses delivered by the dependency versions actually resolved by Gradle.
