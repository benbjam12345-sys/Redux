package com.redux.app;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import io.github.muntashirakon.adb.AdbStream;

/** Executes only command strings built by REDUX's preset actions; this is not a raw terminal. */
public final class AdbCommandRunner {
    private static final int MAX_OUTPUT_BYTES = 24 * 1024;
    private final ReduxAdbConnectionManager manager;

    public AdbCommandRunner(ReduxAdbConnectionManager manager) {
        this.manager = manager;
    }

    public String run(String command) throws Exception {
        AdbStream stream = manager.openStream("shell:" + command);
        try (InputStream in = stream.openInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[2048];
            int n;
            while ((n = in.read(buffer)) != -1) {
                int remaining = MAX_OUTPUT_BYTES - out.size();
                if (remaining <= 0) break;
                out.write(buffer, 0, Math.min(n, remaining));
            }
            String text = out.toString(StandardCharsets.UTF_8.name());
            if (out.size() >= MAX_OUTPUT_BYTES) text += "\n[output truncated by REDUX]";
            return text.trim().isEmpty() ? "(no output)" : text;
        } finally {
            try { stream.close(); } catch (Exception ignored) { }
        }
    }
}
