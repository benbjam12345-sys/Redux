package com.redux.app;

import android.app.Application;
import java.security.Security;
import org.conscrypt.Conscrypt;

public final class ReduxApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // The ADB pairing library uses TLS 1.3. Prefer its bundled Conscrypt provider.
        try {
            if (Conscrypt.isAvailable()) {
                Security.insertProviderAt(Conscrypt.newProvider(), 1);
            }
        } catch (Throwable ignored) {
            // The ADB operation will surface a clear error if the provider is unavailable.
        }
    }
}
