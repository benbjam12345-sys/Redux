package com.redux.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(12, 12, 12);
    private static final int CARD = Color.rgb(23, 23, 23);
    private static final int RED = Color.rgb(242, 29, 53);
    private static final int WHITE = Color.rgb(244, 244, 244);
    private static final int MUTED = Color.rgb(166, 166, 166);
    private static final Pattern PACKAGE = Pattern.compile("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+$");

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private ReduxAdbConnectionManager manager;
    private LinearLayout body;
    private TextView status;
    private TextView outputView;
    private String page = "CONNECT";
    private String lastOutput = "REDUX ready. Pair with Wireless Debugging, then connect.";

    private EditText hostField;
    private EditText pairPortField;
    private EditText pairCodeField;
    private EditText connectPortField;
    private EditText packageField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8, 8, 8));
        getWindow().setNavigationBarColor(Color.rgb(8, 8, 8));
        renderShell();
        showPage("CONNECT");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
        if (manager != null) {
            try { manager.disconnect(); } catch (Exception ignored) { }
        }
    }

    private void renderShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(16), dp(8), dp(16), dp(12));

        TextView title = new TextView(this);
        title.setText("REDUX");
        title.setTextColor(RED);
        title.setTextSize(32);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(44)));

        TextView subtitle = new TextView(this);
        subtitle.setText("QUEST 3S  •  ADB + GAME TOOLKIT  •  ALPHA");
        subtitle.setTextColor(MUTED);
        subtitle.setTextSize(11);
        subtitle.setLetterSpacing(0.07f);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(26)));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(0, dp(8), 0, dp(8));
        nav.addView(navButton("CONNECT", "CONNECT"), weightParams());
        nav.addView(navButton("TOOLS", "TOOLS"), weightParams());
        nav.addView(navButton("MODS", "MODS"), weightParams());
        root.addView(nav, new LinearLayout.LayoutParams(-1, dp(54)));

        status = new TextView(this);
        status.setText("●  DISCONNECTED");
        status.setTextColor(RED);
        status.setTextSize(12);
        status.setPadding(dp(12), dp(6), dp(12), dp(6));
        root.addView(status, new LinearLayout.LayoutParams(-1, dp(30)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        TextView footer = new TextView(this);
        footer.setText("LOCAL CONTROL ONLY  •  NO ROOT / NO ANTI-CHEAT BYPASS");
        footer.setTextColor(MUTED);
        footer.setTextSize(9);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(8), 0, 0);
        root.addView(footer, new LinearLayout.LayoutParams(-1, dp(20)));

        setContentView(root);
    }

    private View navButton(String label, String targetPage) {
        Button button = baseButton(label, false);
        button.setTextSize(11);
        button.setOnClickListener(v -> showPage(targetPage));
        return button;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(40), 1f);
        p.setMargins(dp(3), 0, dp(3), 0);
        return p;
    }

    private void showPage(String target) {
        page = target;
        outputView = null;
        body.removeAllViews();
        if ("CONNECT".equals(target)) renderConnectionPage();
        else if ("TOOLS".equals(target)) renderToolsPage();
        else renderModsPage();
        addOutputBox();
    }

    private void renderConnectionPage() {
        addHeading("WIRELESS DEBUGGING");
        addText("Pairing uses a temporary pairing port + six-digit code. Connecting uses a different session port. For REDUX running on the same Quest, use 127.0.0.1.", MUTED, 13);
        addSpace(10);
        hostField = addField("Host / IP address", "127.0.0.1", InputType.TYPE_CLASS_TEXT);
        pairPortField = addField("Pairing port (from Pair device with code)", "", InputType.TYPE_CLASS_NUMBER);
        pairCodeField = addField("Six-digit pairing code", "", InputType.TYPE_CLASS_NUMBER);
        pairCodeField.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6)});
        connectPortField = addField("Connection port (main Wireless Debugging page)", "", InputType.TYPE_CLASS_NUMBER);

        addButton("OPEN WIRELESS DEBUGGING SETTINGS", true, this::openWirelessSettings);
        addSpace(4);
        addButton("PAIR DEVICE", false, this::doPair);
        addButton("CONNECT TO ADB", false, this::doConnect);
        addButton("DISCONNECT", true, this::doDisconnect);
        addSpace(10);
        addText("Quest tip: after pairing succeeds, return to the main Wireless Debugging page and use its connection port. If leaving the pairing dialog invalidates its temporary port, reopen it and use the new code and port.", MUTED, 12);
    }

    private void renderToolsPage() {
        addHeading("DEVICE / GAME TOOLS");
        addText("These buttons use a small set of preset ADB commands. Connect first. Package names are validated before use; this is not a free-form shell.", MUTED, 13);
        packageField = addField("Game package", "com.AnotherAxiom.GorillaTag", InputType.TYPE_CLASS_TEXT);
        addButton("CHECK ADB + DEVICE INFO", false, () -> runPreset("Reading device information…", "getprop ro.product.model; getprop ro.build.version.release; getprop ro.build.version.sdk"));
        addButton("LIST USER-INSTALLED PACKAGES", true, () -> runPreset("Listing packages…", "pm list packages -3"));
        addButton("CHECK SELECTED GAME INSTALL", true, () -> withPackage(pkg -> runPreset("Checking package path…", "pm path " + pkg)));
        addButton("LAUNCH SELECTED GAME", false, () -> withPackage(pkg -> runPreset("Launching game…", "monkey -p " + pkg + " -c android.intent.category.LAUNCHER 1")));
        addButton("FORCE-STOP SELECTED GAME", true, this::confirmStopGame);
        addButton("CAPTURE LAST 250 LOG LINES", true, () -> runPreset("Collecting a short local log excerpt…", "logcat -d -t 250"));
        addText("Logs may contain app names, errors, or other device information. Keep output private before sharing it.", MUTED, 11);
    }

    private void renderModsPage() {
        addHeading("MOD FEATURE LIBRARY");
        addText("Inventory collected from the four APKs you supplied. These rows are not yet live gameplay toggles: a compatible game-side plugin is required for real movement changes.", MUTED, 13);
        addSpace(8);
        addFeature("MOVEMENT", "Fly · Hover Fly · Joystick Fly · Velocity Fly · Noclip Fly · Stick Fly · Long Arms · Teleports & Bursts · Wall Walk · Spider-Man · Hand Platforms · Speed Boost");
        addFeature("PLAYER", "Ghost Monke · Headbang · Rig controls · Player controls");
        addFeature("VISUALS", "Camera · Brightness · Player highlights · Eye / map / stump / gauge controls");
        addFeature("UTILITY", "Settings · Reconnect · Game launch / force-stop · Diagnostics · Feature configuration");
        addSpace(8);
        addText("BRIDGE STATUS: NOT DETECTED", RED, 13);
        addText("ADB grants shell-level device commands after you explicitly pair. It does not by itself inject code into Gorilla Tag or every fan game. REDUX will only activate a feature once a supported game runtime/bridge is supplied and verified for that game.", MUTED, 12);
        addSpace(8);
        addButton("OPEN RESEARCH NOTES", true, () -> new AlertDialog.Builder(this)
                .setTitle("REDUX research status")
                .setMessage("Delta and Stripes share several ADB classes and menu labels. Lunex has explicit wireless-pairing components. Moonlit has a much larger, different dependency surface. PCVR BepInEx/Mono mod DLLs and root/Frida-based Quest projects are not safe drop-in modules for this APK.")
                .setPositiveButton("OK", null).show());
    }

    private void addFeature(String category, String description) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(shape(CARD, RED, 1, 12));
        TextView header = new TextView(this);
        header.setText(category);
        header.setTextColor(RED);
        header.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.setTextSize(14);
        card.addView(header);
        TextView text = new TextView(this);
        text.setText(description);
        text.setTextColor(WHITE);
        text.setTextSize(12);
        text.setPadding(0, dp(5), 0, dp(7));
        card.addView(text);
        TextView state = new TextView(this);
        state.setText("CATALOGUED  •  REQUIRES COMPATIBLE GAME RUNTIME");
        state.setTextColor(MUTED);
        state.setTextSize(9);
        card.addView(state);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(4), 0, dp(8));
        body.addView(card, lp);
    }

    private void openWirelessSettings() {
        Intent intent = new Intent("android.settings.WIRELESS_DEBUGGING_SETTINGS");
        try {
            startActivity(intent);
        } catch (Exception first) {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
            catch (Exception second) { toast("Open Settings > Developer options > Wireless debugging manually."); }
        }
    }

    private void doPair() {
        String host = hostField == null ? "127.0.0.1" : hostField.getText().toString().trim();
        String portString = pairPortField == null ? "" : pairPortField.getText().toString().trim();
        String code = pairCodeField == null ? "" : pairCodeField.getText().toString().trim();
        int port;
        try { port = validPort(portString); }
        catch (Exception e) { toast("Enter the pairing port shown by Wireless Debugging."); return; }
        if (!validHost(host)) { toast("Enter a valid host/IP address."); return; }
        if (!code.matches("\\d{6}")) { toast("The pairing code must be exactly six digits."); return; }

        runTask("Pairing with Wireless Debugging…", () -> {
            ReduxAdbConnectionManager m = getManager();
            boolean ok = m.pair(host, port, code);
            return ok ? "Pairing succeeded. Now enter the separate connection port and tap CONNECT." : "Pairing failed. Confirm the pairing dialog is still open and re-enter the current code and pairing port.";
        }, false);
    }

    private void doConnect() {
        String host = hostField == null ? "127.0.0.1" : hostField.getText().toString().trim();
        String portString = connectPortField == null ? "" : connectPortField.getText().toString().trim();
        int port;
        try { port = validPort(portString); }
        catch (Exception e) { toast("Enter the connection port from the main Wireless Debugging page."); return; }
        if (!validHost(host)) { toast("Enter a valid host/IP address."); return; }

        runTask("Connecting to ADB…", () -> {
            boolean ok = getManager().connect(host, port);
            if (!ok) return "Connection was not established. Try the current connection port; if the host was already connected, disconnect first.";
            String model = new AdbCommandRunner(getManager()).run("getprop ro.product.model");
            return "CONNECTED to " + host + ":" + port + "\nDevice: " + model;
        }, true);
    }

    private void doDisconnect() {
        runTask("Disconnecting…", () -> {
            if (manager != null) manager.disconnect();
            return "Disconnected. Wireless debugging remains enabled in Android settings until you turn it off.";
        }, false);
    }

    private void confirmStopGame() {
        withPackage(pkg -> new AlertDialog.Builder(this)
                .setTitle("Force-stop game?")
                .setMessage("REDUX will stop this package on the connected Android device:\n\n" + pkg)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Force-stop", (dialog, which) -> runPreset("Stopping package…", "am force-stop " + pkg))
                .show());
    }

    private interface PackageAction { void run(String packageName); }
    private void withPackage(PackageAction action) {
        String pkg = packageField == null ? "" : packageField.getText().toString().trim();
        if (!PACKAGE.matcher(pkg).matches()) {
            toast("Enter a valid Android package name, for example com.example.game.");
            return;
        }
        action.run(pkg);
    }

    private void runPreset(String message, String command) {
        runTask(message, () -> new AdbCommandRunner(getManager()).run(command), true);
    }

    private ReduxAdbConnectionManager getManager() throws Exception {
        if (manager == null) manager = new ReduxAdbConnectionManager(getApplicationContext());
        return manager;
    }

    private void runTask(String workingMessage, Task task, boolean connectedAfterSuccess) {
        setStatus("●  " + workingMessage, MUTED);
        io.submit(() -> {
            String result;
            boolean success = false;
            try {
                result = task.run();
                String normalized = result.trim().toLowerCase(Locale.ROOT);
                success = !normalized.startsWith("error:")
                        && !normalized.startsWith("pairing failed")
                        && !normalized.startsWith("connection was not established");
            } catch (Throwable e) {
                result = "ERROR: " + e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage())
                        + "\n\nCheck the current pairing/connection ports, keep Wireless Debugging enabled, and retry.";
            }
            final String finalResult = result;
            final boolean finalSuccess = success;
            runOnUiThread(() -> {
                lastOutput = finalResult;
                setStatus(finalSuccess ? "●  " + (connectedAfterSuccess ? "CONNECTED / READY" : "OPERATION COMPLETE") : "●  CHECK OUTPUT", finalSuccess ? RED : MUTED);
                if (outputView != null) outputView.setText(lastOutput);
            });
        });
    }

    private interface Task { String run() throws Exception; }

    private void setStatus(String text, int color) {
        if (status != null) {
            status.setText(text);
            status.setTextColor(color);
        }
    }

    private void addOutputBox() {
        addSpace(12);
        addHeading("OUTPUT");
        outputView = new TextView(this);
        outputView.setText(lastOutput);
        outputView.setTextColor(WHITE);
        outputView.setTextSize(11);
        outputView.setTextIsSelectable(true);
        outputView.setPadding(dp(12), dp(12), dp(12), dp(12));
        outputView.setBackground(shape(Color.rgb(5, 5, 5), Color.rgb(70, 70, 70), 1, 8));
        body.addView(outputView, new LinearLayout.LayoutParams(-1, -2));
    }

    private EditText addField(String label, String initial, int inputType) {
        TextView caption = new TextView(this);
        caption.setText(label);
        caption.setTextColor(MUTED);
        caption.setTextSize(11);
        caption.setPadding(0, dp(6), 0, dp(4));
        body.addView(caption, new LinearLayout.LayoutParams(-1, -2));

        EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setText(initial);
        field.setHint(label);
        field.setTextColor(WHITE);
        field.setHintTextColor(Color.rgb(100, 100, 100));
        field.setTextSize(14);
        field.setInputType(inputType | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        field.setPadding(dp(10), dp(4), dp(10), dp(4));
        field.setBackground(shape(CARD, Color.rgb(90, 25, 34), 1, 8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.setMargins(0, 0, 0, dp(3));
        body.addView(field, lp);
        return field;
    }

    private void addHeading(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(RED);
        v.setTextSize(16);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setPadding(0, dp(8), 0, dp(5));
        body.addView(v, new LinearLayout.LayoutParams(-1, -2));
    }

    private void addText(String text, int color, int size) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(color);
        v.setTextSize(size);
        v.setLineSpacing(dp(2), 1f);
        body.addView(v, new LinearLayout.LayoutParams(-1, -2));
    }

    private void addButton(String text, boolean secondary, Runnable action) {
        Button button = baseButton(text, secondary);
        button.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(46));
        lp.setMargins(0, dp(4), 0, dp(4));
        body.addView(button, lp);
    }

    private Button baseButton(String label, boolean secondary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(WHITE);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(shape(secondary ? CARD : RED, secondary ? Color.rgb(76, 27, 34) : RED, 1, 10));
        return b;
    }

    private GradientDrawable shape(int fill, int stroke, int strokeWidth, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(strokeWidth), stroke);
        return d;
    }

    private int validPort(String text) {
        int port = Integer.parseInt(text);
        if (port < 1 || port > 65535) throw new IllegalArgumentException("port out of range");
        return port;
    }

    private boolean validHost(String host) {
        return host != null && !host.isEmpty() && host.length() < 256
                && host.matches("[A-Za-z0-9_.:%-]+") && !host.contains("..") && !host.startsWith("-");
    }

    private void addSpace(int heightDp) {
        View spacer = new View(this);
        body.addView(spacer, new LinearLayout.LayoutParams(1, dp(heightDp)));
    }

    private int dp(float d) {
        return (int) (d * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }
}
