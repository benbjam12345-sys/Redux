# Test plan

The project still needs a real Android SDK build and a Quest 3S runtime pass. Before installing on the headset, validate at least:

- Gradle dependency resolution and `assembleDebug` succeeds.
- First app launch creates a stable ADB identity in REDUX private storage.
- Pair fails clearly for an incorrect/expired six-digit code.
- Pair succeeds only when the correct pairing dialog/port is active.
- Connect uses the separate session port and can be retried after a Wireless Debugging restart.
- Disconnect closes the ADB session.
- The package-name validator blocks spaces, shell separators, and malformed identifiers.
- Device info and package listing show bounded output and do not crash the UI.
- Force-stop always requests confirmation.
- Unsupported movement options remain catalog-only until a compatible game bridge is integrated.
