# REDUX — Android ADB Controller (development source)

REDUX is a black-and-red Android controller project aimed at Meta Quest 3S and other Android devices. This source release combines a wireless ADB pairing/connection screen, a small set of bounded device/game-management utilities, and a researched catalog of Gorilla Tag-style mod features.

> **Build status:** source project only. This environment did not have Android SDK/Gradle installed, so no installable APK was built or runtime-tested. Use the included GitHub Actions workflow to build a debug APK after uploading the folder to a GitHub repository, or open it in Android Studio with Android SDK 35 installed.

## Included now

- Persistent ADB identity and wireless debugging pairing via `libadb-android`.
- Separate pairing-port + 6-digit pairing-code fields and a separate connection-port field.
- Default host `127.0.0.1` for the Quest running REDUX itself. Change this to the other Android device's LAN address only when connecting to a different device.
- Safe preset tools: read device properties, list third-party packages, check the target game's install path, launch/stop a selected game package, and capture a short logcat excerpt.
- A mod feature inventory based on strings found in the uploaded APKs (and public repository research).
- A bridge-readiness notice instead of fake toggles. A companion game-side mod runtime must exist for gameplay features to actually alter movement; the controller APK by itself cannot change a Unity game's internal movement code.
- GitHub Actions workflow to build `app-debug.apk` and publish it as an artifact.

## Important reality check

The uploaded APKs are controller apps, not source projects containing one shared, portable mod runtime. Delta and Stripes share many class names/resources and ADB library references, Lunex contains more complete wireless-pairing strings and additional UI, while Moonlit has a much larger app dependency surface. Blindly merging all DEX files, manifests, native libraries, and signing metadata is not a valid Android build strategy. This project re-implements a clean controller layer rather than repackaging unverified code or claims.

The menu feature catalog currently does **not** implement in-game Fly, Noclip, Ghost, Long Arms, etc. Those features require a compatible, game-specific mod plugin/runtime. REDUX deliberately displays them as catalog items until that runtime is verified; the UI will not pretend a button worked when only a local preference changed.

## Build

### GitHub Actions (no local PC toolchain required after repository upload)

1. Upload the contents of this folder to a repository you control. Keep `.github/workflows/android-build.yml` in the repo.
2. Open the repository's **Actions** tab and run **Build REDUX Android APK** (or push a commit to `main`/`master`).
3. Open the completed workflow run and download the `REDUX-debug-apk` artifact.
4. Extract the artifact ZIP and install `app-debug.apk` on the Quest 3S using your usual APK installer.

A repository upload/build is still required; this chat environment cannot sign or install an APK onto your headset.

### Android Studio

Open this folder as a Gradle project with JDK 17 and Android SDK Platform 35 installed. Gradle dependencies are fetched from Google Maven, Maven Central, and JitPack. Run `assembleDebug`.

## Pairing on the Quest itself

1. In REDUX, leave host as `127.0.0.1` for the Quest's own ADB daemon.
2. Open Android/Quest **Wireless debugging** settings and choose **Pair device with pairing code**.
3. Enter the pairing port and the six-digit code shown in that pairing dialog, then tap **PAIR**.
4. Return to the main Wireless debugging screen and enter its separate **IP address & Port** connection port in REDUX, then tap **CONNECT**.
5. Keep Wireless debugging enabled. Ports may change when the service restarts. If switching out of the pairing dialog closes it, reopen the dialog and use the newly displayed code/port.

For a different Android device on the same network, use that device's LAN IP address instead of `127.0.0.1`. Only pair with a device you own or are authorized to administer.

## Scope and safety

REDUX is intended for your own device and private/fan-game development/testing. It does not include root exploits, anti-cheat bypasses, stealth, or public-lobby advantage features. The built-in ADB actions are limited presets, not an arbitrary shell terminal. Read every confirmation before force-stopping a package or collecting logs.

## Uploaded APK evidence

See [`docs/APK-REVIEW.md`](docs/APK-REVIEW.md) for findings from `MoonlitV2.apk`, `DeltaV67.apk`, `stripesadb-783.apk`, and `Lunex (29).apk`. See [`docs/RESEARCH.md`](docs/RESEARCH.md) for public-source findings and compatibility notes.
