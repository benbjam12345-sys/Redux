# Game-side bridge requirements

The REDUX APK and a Gorilla Tag-style game's Unity runtime are two separate processes. ADB can run supported Android shell services after the user explicitly pairs, but it cannot directly call the game's C# movement methods. A real gameplay toggle therefore needs a bridge/runtime inside the game, built for that specific title/build.

A compatible private/fan-game bridge should:

1. Expose a local-only interface (for example, a loopback TCP endpoint or an exported, permission-protected Android receiver).
2. Authenticate/validate each message and accept only a fixed command schema such as `{ "feature": "fly", "enabled": true }`.
3. Execute changes on Unity's main thread.
4. Return capability and version information so REDUX can grey out unsupported features rather than pretending they worked.
5. Default to local/private testing and avoid anti-cheat bypasses, stealth, public-lobby manipulation, or elevated root requirements.

Feature names collected from the supplied APKs are an inventory, not proof that every target game supports those actions. For a fan game, its developer can add the bridge to the game's code. For a third-party game, only a supported plugin/runtime for that exact Android build can implement it.
