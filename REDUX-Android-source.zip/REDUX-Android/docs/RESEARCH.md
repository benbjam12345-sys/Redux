# Public repository research: ADB clients and Gorilla Tag-style mod projects

Search performed on public GitHub/web results on 27 November 2026. This is a curated search, not a literal scan of every website or private repository.

## Suitable controller foundation

### MuntashirAkon/libadb-android
- URL: https://github.com/MuntashirAkon/libadb-android
- Purpose: Android ADB protocol library supporting the pairing step, TLS connection, and `shell:` services; its README documents `pair(host, port, pairingCode)`, `connect(host, port)`, `openStream(...)`, and `disconnect()`.
- License: dual-licensed GPL-3.0-or-later or Apache-2.0; it has additional transitive crypto/pairing dependencies whose licenses need to be preserved if redistributed.
- REDUX usage: dependency only; no library source is copied into this repository.

### pabloajoinglez/AdbShellTool
- URL: https://github.com/pabloajoinglez/AdbShellTool
- Purpose: small Android app focused on pairing to Wireless Debugging on Android 11+ and running shell commands locally without a PC.
- License: MIT.
- REDUX usage: architectural reference only, not copied source code. Its README also warns that the pairing and connection ports are different and that the pairing dialog must stay available during the pairing step.

### tananaev/adblib
- URL: https://github.com/tananaev/adblib
- Purpose: older Java implementation of the ADB network protocol. The README's classic example assumes a TCP ADB daemon (`adb tcpip 5555`).
- REDUX usage: helps explain the class names found in Delta and Stripes. It is not used as REDUX's wireless-pairing engine by itself because Android 11+ Wireless Debugging requires the pairing/TLS flow.

### tytydraco/LADB
- URL: https://github.com/tytydraco/ladb
- Purpose: local ADB shell app using Android's Wireless Debugging support.
- License note: its repository describes license terms with a restriction about unofficial builds in Google Play. REDUX does not copy or redistribute its source.

## Game-mod repositories investigated

### Qubit Menu
- URL: https://github.com/QubitManagement/Qubit-Menu
- Description: community Gorilla Tag menu with modular movement, visual, important, and settings categories; repository documentation describes C#/Unity plus BepInEx/MelonLoader.
- Relevance: useful as a feature taxonomy and an example of a game-side mod architecture. Its mod code is not a portable Android ADB module and has not been integrated into REDUX.

### lemonlord22/ModMenu
- URL: https://github.com/lemonlord22/ModMenu
- Description: Gorilla Tag mod delivered as a DLL for a BepInEx plugin folder. Its README explicitly says it is not for public servers.
- Relevance: PCVR/plugin architecture only; not a drop-in module for a standalone Android controller APK.

### gieneklachowicz-ui/MODtemp
- URL: https://github.com/gieneklachowicz-ui/MODtemp
- Description: BepInEx Gorilla Tag mod template.
- Relevance: relevant only if developing a game-side plugin with matching Unity/game assemblies; it is not an ADB app.

### AndroidModLoader (AML)
- URLs: https://github.com/gmh5225/Android-ModLoader and https://github.com/RusJJ/AndroidModLoader
- Description: Android native mod-loader research project. Its public README notes that Unity/IL2CPP support requires external tools and is not ready as a universal drop-in Gorilla Tag solution.
- Relevance: not included. It would require separate source review, compatibility testing, and careful security/permission analysis before being considered.

### ii's Quest Menu / Frida-based ports
- Examples: https://github.com/iiDkRemastered/iis.quest.menu and https://github.com/GunyahIsTuff/iis.Quest.Menu.Animal.Company
- Description: public repositories describe standalone Quest menu experiments using Frida/IL2CPP techniques and root/exploit-related setup.
- Relevance: not included. Exploit/root prerequisites create device-integrity and stability risks; REDUX will not reproduce those exploit steps or use them as a default install path.

### Rexon Mod Menu and similar PCVR DLL menus
- URL: https://github.com/Wyvern-Softworks/Rexon-Mod-Menu
- Description: C# Unity menu targeting Windows x64, .NET Framework, and PCVR injection/plugin dependencies.
- Relevance: not directly compatible with an Android APK. The code should not be represented as portable to Quest just because the game name is the same.

## Integration decision

REDUX currently incorporates the current ADB protocol dependency and a controller feature inventory. It does **not** bundle binary DLLs, root tools, Frida servers, injection code, or mod projects with different licenses and runtimes. The next valid step for actual in-game toggles is to identify a supported game-side plugin/bridge and verify the target game version and feature API for a private/fan-game build.
