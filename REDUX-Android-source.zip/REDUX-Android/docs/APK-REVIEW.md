# Uploaded APK review (static string and archive inspection)

These notes describe only what was visible in the uploaded package structure, file list, and DEX string tables. They are not a full source decompilation, behavioral audit, or malware scan.

## `DeltaV67.apk` (about 86 KB)

- Contains one `classes.dex`, a small Android manifest/resource set, and icons/layout for a mod-oriented dashboard.
- DEX strings include `com.tananaev.adblib` classes, `AdbManager`, connection/reconnect labels, `Launch Gorilla Tag`, the package `com.AnotherAxiom.GorillaTag`, and feature strings such as `Hover Fly`, `Long Arms`, `Noclip Fly`, `Ghost Monke`, `Joystick Fly`, `Velocity Fly`, `STICK_FLY`, `HEADBANG`, and `TELEPORTS AND BURSTS`.
- It also contains `am force-stop` and `monkey` command strings, suggesting it uses ADB shell commands for at least some app actions.

## `stripesadb-783.apk` (about 3.3 MB)

- Contains one DEX plus `lib/arm64-v8a/libadb.so` and a similar set of `res/drawable/ic_*.xml` icons to Delta.
- Strings include `EmbeddedAdbHost`, `AdbManager`, the older `com.tananaev.adblib` package, a pairing code/port workflow, and many of the same feature labels seen in Delta.
- The identical/similar class names and UI resource naming suggest overlapping code or a common base, but not every class is guaranteed to be identical.

## `Lunex (29).apk` (about 6.1 MB)

- Contains two DEX files, keymapper and AI layouts, and a more explicit wireless debugging/pairing vocabulary.
- Strings include `AdbPairingRequiredException`, `pair_port`, a six-digit code prompt, `libadb-android` namespaces (`io.github.muntashirakon.adb`), pairing-auth/TLS messages, and additional movement-assist labels.
- It appears to contain a newer/different ADB implementation alongside the shared/older `com.tananaev.adblib` code paths.

## `MoonlitV2.apk` (about 19 MB)

- Contains multiple DEX files, native `libspake2.so` variants, and extensive AndroidX/Google/Firebase/authentication dependency resources.
- A few strings mention wireless ADB pairing, `dev.moonlit.quest.action.CONNECT`, and movement-assist labels. Its much larger dependency surface is not equivalent to the smaller Delta/Stripes controller structure.
- Because the archive contains substantial unrelated infrastructure, wholesale merging of its DEX files or native libraries would create conflicts and should not be attempted.

## Conclusion

REDUX borrows no unverified binary code from these APKs. It reproduces a clean controller UI and uses a current public ADB protocol library for pairing/connection. Menu labels are listed in the feature catalog for traceability. A live feature needs a compatible game-side runtime or plugin; an ADB connection alone does not implement the game's movement methods.
